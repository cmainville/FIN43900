# Design: Add Jim Simons & Robert Shiller Expert Perspectives

**Date:** 2026-02-16
**Status:** Approved
**Version:** financial-researcher 2.0.0 → 2.1.0

---

## Summary

Add two new expert perspectives to the financial-researcher plugin, expanding from 7 to 9 guru analysts:

- **Jim Simons** ("The Quant") — Quantitative/systematic analysis: factor exposure, momentum, volatility regimes, mean reversion, statistical anomalies, relative strength, correlation structure, liquidity, and return distribution.
- **Robert Shiller** ("The Behavioral Economist") — Behavioral economics + long-term valuation: CAPE ratio, bubble detection, narrative analysis, mean reversion probability, historical analogues.

**Approach:** Parallel addition (Approach A). Both experts are independent modules that follow the existing expert pattern. Full Python metrics integration.

---

## Gap Analysis

### Current Lineup (7 experts)

| Category | Experts |
|----------|---------|
| Value | Warren Buffett, Ben Graham |
| Growth | Peter Lynch, Cathie Wood |
| Macro/Cycles | George Soros, Ray Dalio |
| Contrarian/Forensics | Michael Burry |

### Missing Perspectives

| Perspective | Gap | Filled By |
|-------------|-----|-----------|
| Quantitative/Systematic | No factor-based, statistical, or probability-framed analysis | Jim Simons |
| Behavioral/Academic Valuation | No CAPE, bubble detection, or narrative economics lens | Robert Shiller |

---

## New Python Metrics

### Jim Simons — Quant Factor Metrics (9 functions)

New file: `processing/quant_metrics.py`

| Function | Calculates | Inputs |
|----------|-----------|--------|
| `momentum_score()` | 6/12-month price momentum (Jegadeesh & Titman), momentum persistence, trend strength | Stock price history |
| `volatility_metrics()` | Realized vol (20d, 60d, 252d), vol regime (high/low/normal), vol-of-vol, VIX context | Stock prices + VIX data |
| `mean_reversion_signals()` | Z-score vs 50/200 day MA, RSI, Bollinger Band position, distance from 52-week range | Stock prices |
| `factor_exposure()` | Composite factor scores: value (P/E, P/B percentile), quality (ROE, accruals), size (log market cap), momentum | Existing metrics + prices |
| `statistical_anomalies()` | Skewness/kurtosis of returns, unusual volume patterns, price-earnings divergence | Prices + financials |
| `sector_relative_strength()` | Stock vs sector ETF, sector vs SPY, relative outperformance over 1m/3m/6m/12m | Stock + sector ETF + SPY prices |
| `correlation_regime()` | Rolling correlation to SPY (30d, 90d, 252d), correlation breakdown detection, beta stability | Stock + SPY prices |
| `liquidity_metrics()` | Amihud illiquidity ratio, high-low spread proxy, volume trend, abnormal volume detection | Price + volume history |
| `return_distribution()` | Skewness, kurtosis, CVaR at 5%, max drawdown, Sharpe proxy | Price history |

### Robert Shiller — Behavioral/Valuation Metrics (3 functions)

New file: `processing/behavioral_metrics.py`

| Function | Calculates | Inputs |
|----------|-----------|--------|
| `cape_ratio()` | Cyclically-Adjusted P/E using up to 10yr average real earnings, excess CAPE yield, CAPE-implied long-term return | Earnings history (from 15yr data) + current price |
| `bubble_indicators()` | Price-to-trend deviation, earnings growth vs price growth divergence, valuation percentile vs own history | Prices + earnings history |
| `narrative_momentum_score()` | Quantitative proxy — news sentiment ratio, analyst estimate dispersion, search interest indicators | News data (Tavily) + analyst estimates |

### ComprehensiveAnalysis Dataclass Updates

```python
# New fields in metrics_calculator.py ComprehensiveAnalysis:

# Quant Metrics (Simons)
momentum: Optional[MetricResult] = None
volatility: Optional[MetricResult] = None
mean_reversion: Optional[MetricResult] = None
factor_exposure: Optional[MetricResult] = None
statistical_anomalies: Optional[MetricResult] = None
sector_relative_strength: Optional[MetricResult] = None
correlation_regime: Optional[MetricResult] = None
liquidity: Optional[MetricResult] = None
return_distribution: Optional[MetricResult] = None

# Behavioral Metrics (Shiller)
cape: Optional[MetricResult] = None
bubble_indicators: Optional[MetricResult] = None
narrative_momentum: Optional[MetricResult] = None
```

---

## Expert Prompt Design

### Jim Simons — "The Quant"

**Philosophy:** Markets have exploitable statistical patterns. Emotion is noise; data is signal. Every position is a probability bet, not a conviction trade.

**Time Horizon:** Medium-term (1-6 months)

**Analysis Criteria (scored 1-10 each):**

| Criterion | Evaluates |
|-----------|-----------|
| Momentum Profile | 6/12-month momentum, persistence, trend strength |
| Mean Reversion Setup | Distance from statistical fair value, RSI extremes, Bollinger positioning |
| Factor Exposure | Value/quality/momentum/size factor tilts — crowded or uncrowded? |
| Volatility Regime | Current vol vs historical, vol regime, VIX context |
| Statistical Edge | Return distribution anomalies, exploitable patterns |
| Relative Strength | vs SPY, vs sector ETF, leadership or laggard |
| Liquidity & Execution | Can a position be built/exited? Abnormal volume? |
| Correlation Structure | Beta stability, market coupling/decoupling, diversification value |
| Risk/Reward Profile | Sharpe proxy, max drawdown, tail risk (CVaR), payoff asymmetry |

**Unique Output Elements:**
- Probability-framed signal (e.g., "68% probability of positive 3-6 month return")
- Position sizing suggestion based on monthly volatility (Kelly-adjacent)
- Medium-term time horizon (1-6 months)

**13-F Source:** `RENAISSANCE_TECHNOLOGIES_LLC`

### Robert Shiller — "The Behavioral Economist"

**Philosophy:** Markets are driven by narratives and psychology as much as fundamentals. Long-term valuation reverts to mean, but bubbles can persist far longer than expected.

**Time Horizon:** Long-term (5-10 years)

**Analysis Criteria (scored 1-10 each):**

| Criterion | Evaluates |
|-----------|-----------|
| CAPE Valuation | Cyclically-adjusted P/E vs historical median, excess CAPE yield |
| Bubble Risk Assessment | Price-to-trend deviation, speculative behavior, valuation percentile |
| Narrative Analysis | What stories drive this stock? How durable? Historical parallels? |
| Mean Reversion Probability | Distance from long-term norms, expected reversion timeline |
| Market Psychology | Sentiment indicators, analyst optimism/pessimism dispersion |
| Historical Analogues | Similar valuation/narrative episodes and their outcomes |
| Long-Term Return Forecast | 5-10yr annualized return implied by current CAPE |

**Unique Output Elements:**
- CAPE-implied return forecast (e.g., "Current CAPE of 28 implies ~4% real annual returns over next decade")
- Bubble probability rating (0-100%)
- Historical analogue comparison (e.g., "Resembles tech sector in 1998")

**13-F Source:** None (academic, not a fund manager)

---

## Data Requirements

### New Data Fetches (3 + 1)

```python
# Market benchmarks (added to DISCOVER phase)
get_prices(ticker="SPY", start_date="{FIVE_YEARS_AGO}", end_date="{TODAY}", interval="day")
get_prices(ticker="{SECTOR_ETF}", start_date="{FIVE_YEARS_AGO}", end_date="{TODAY}", interval="day")
get_prices(ticker="^VIX", start_date="{FIVE_YEARS_AGO}", end_date="{TODAY}", interval="day")
# Fallback: get_prices(ticker="VIXY", ...) if ^VIX unavailable

# Renaissance 13-F holdings
get_institutional_ownership(
    investor="RENAISSANCE_TECHNOLOGIES_LLC",
    limit=300,
    report_period_gte="{THREE_YEARS_AGO}"
)
```

### Sector ETF Mapping

| Sector | ETF |
|--------|-----|
| Technology | XLK |
| Healthcare | XLV |
| Financials | XLF |
| Consumer Discretionary | XLY |
| Consumer Staples | XLP |
| Industrials | XLI |
| Energy | XLE |
| Materials | XLB |
| Utilities | XLU |
| Real Estate | XLRE |
| Communication Services | XLC |

### Data Routing Matrix (9 experts)

```
┌─────────────────┬────┬────┬────┬────┬────┬────┬────┬────┬────┐
│ Data Type       │ WB │ BG │ PL │ CW │ GS │ RD │ MB │ JS │ RS │
├─────────────────┼────┼────┼────┼────┼────┼────┼────┼────┼────┤
│ income_stmts    │ ✓  │ ✓  │ ✓  │ ✓  │    │    │ ✓  │    │ ✓  │
│ balance_sheets  │ ✓  │ ✓  │ ✓  │ ✓  │    │ ✓  │ ✓  │    │    │
│ cash_flows      │ ✓  │ ✓  │ ✓  │ ✓  │    │ ✓  │ ✓  │    │    │
│ financial_metrics│ ✓  │ ✓  │ ✓  │ ✓  │ ✓  │ ✓  │ ✓  │ ✓  │ ✓  │
│ company_facts   │ ✓  │    │ ✓  │ ✓  │    │    │ ✓  │ ✓  │ ✓  │
│ prices (stock)  │ ✓  │ ✓  │ ✓  │ ✓  │ ✓  │ ✓  │ ✓  │ ✓  │ ✓  │
│ prices (SPY)    │    │    │    │    │    │    │    │ ✓  │    │
│ prices (sector) │    │    │    │    │    │    │    │ ✓  │    │
│ VIX data        │    │    │    │    │    │    │    │ ✓  │    │
│ insider_trades  │ ✓  │    │ ✓  │    │    │    │ ✓  │    │    │
│ sec_filings     │ ✓  │ ✓  │ ✓  │ ✓  │    │ ✓  │ ✓  │    │    │
│ 13f_berkshire   │ ✓  │    │    │    │    │    │    │    │    │
│ 13f_ark         │    │    │    │ ✓  │    │    │    │    │    │
│ 13f_soros       │    │    │    │    │ ✓  │    │    │    │    │
│ 13f_bridgewater │    │    │    │    │    │ ✓  │    │    │    │
│ 13f_scion       │    │    │    │    │    │    │ ✓  │    │    │
│ 13f_renaissance │    │    │    │    │    │    │    │ ✓  │    │
│ news_finance    │ ✓  │    │ ✓  │ ✓  │ ✓  │    │ ✓  │    │ ✓  │
│ news_recent     │ ✓  │ ✓  │ ✓  │ ✓  │ ✓  │ ✓  │ ✓  │    │ ✓  │
│ news_risks      │    │    │    │    │    │ ✓  │ ✓  │    │    │
│ analyst_estimates│    │    │    │    │    │    │    │    │ ✓  │
└─────────────────┴────┴────┴────┴────┴────┴────┴────┴────┴────┘

Legend: WB=Buffett, BG=Graham, PL=Lynch, CW=Wood, GS=Soros, RD=Dalio, MB=Burry, JS=Simons, RS=Shiller
```

---

## File Changes

### New Files (4)

| File | Purpose |
|------|---------|
| `experts/jim_simons.md` | Quant expert prompt template |
| `experts/robert_shiller.md` | Behavioral economist prompt template |
| `processing/quant_metrics.py` | 9 quant metric functions |
| `processing/behavioral_metrics.py` | 3 behavioral metric functions |

### Modified Files (7)

| File | Changes |
|------|---------|
| `processing/metrics_calculator.py` | Add 12 new Optional[MetricResult] fields to ComprehensiveAnalysis. Update `aggregate_flags()` and `calculate_quality_score()`. |
| `processing/orchestrator.py` | Import new metrics. Add calculation blocks in `calculate_all_metrics()`. Add "simons" and "shiller" to `format_for_expert()`. Update `to_llm_context()`. |
| `processing/data_extractor.py` | Add `benchmark_prices` to CompanyData (SPY, sector ETF, VIX). Add `sector_to_etf()` mapping function. |
| `processing/__init__.py` | Export new modules. |
| `SKILL.md` | 9-expert orchestration: diagram, data routing, fetch sequence (+SPY, sector ETF, VIX, Renaissance 13-F), dispatch (9 parallel Tasks), consolidation, report template, guru table. |
| `templates/consolidated_report_template.md` | Add Simons and Shiller sections. Update agreement matrix (9 columns). |
| `.claude-plugin/plugin.json` | Version bump 2.0.0 → 2.1.0. |

### Unchanged Files

- `experts/warren_buffett.md` through `experts/michael_burry.md` — existing experts untouched
- `processing/financial_metrics.py` — legacy, not modified
- `processing/test_pipeline.py` — out of scope (separate test update task)

### Dependency Map

```
quant_metrics.py ──────┐
                       ├──> metrics_calculator.py ──> orchestrator.py ──> SKILL.md
behavioral_metrics.py ─┘                                    │
                                                            ├──> jim_simons.md
data_extractor.py (benchmark prices) ──────────────────────┘    robert_shiller.md
```

No new external dependencies. All calculations use Python stdlib (`math`, `statistics`).

---

## Performance Impact

| Phase | Current | After | Delta |
|-------|---------|-------|-------|
| DISCOVER | ~30s | ~35s | +5s (3 price fetches + 1 13-F) |
| PROCESS | ~5s | ~7s | +2s (12 new metric functions) |
| IMPLEMENT | ~180s | ~180s | ~0s (parallel dispatch) |
| **Total** | **~4 min** | **~4.5 min** | **+30s** |

---

## Expert-to-Metric Mapping (Complete, 9 experts)

```
┌─────────────┬───────────┬─────────┬──────────┬────────┬──────┬────────┬───────┬────────┬──────────┬──────┬────────┬──────────┐
│ Expert      │ Piotroski │ Altman  │ Beneish  │ Owner  │ ROIC │ Graham │ Val.  │ Growth │ Momentum │ CAPE │ Bubble │ Factors  │
├─────────────┼───────────┼─────────┼──────────┼────────┼──────┼────────┼───────┼────────┼──────────┼──────┼────────┼──────────┤
│ Buffett     │     ✓     │         │          │   ✓    │  ✓   │        │   ✓   │   ✓    │          │      │        │          │
│ Graham      │     ✓     │    ✓    │          │        │      │   ✓    │   ✓   │   ✓    │          │      │        │          │
│ Lynch       │     ✓     │         │          │        │      │        │   ✓   │   ✓    │          │      │        │          │
│ Wood        │           │         │          │        │      │        │   ✓   │   ✓    │          │      │        │          │
│ Soros       │           │         │          │        │      │        │   ✓   │        │          │      │        │          │
│ Dalio       │     ✓     │    ✓    │          │        │  ✓   │        │   ✓   │   ✓    │          │      │        │          │
│ Burry       │     ✓     │    ✓    │    ✓     │   ✓    │      │        │   ✓   │   ✓    │          │      │        │          │
│ Simons      │           │         │          │        │      │        │       │        │    ✓     │      │        │    ✓     │
│ Shiller     │           │         │          │        │      │        │   ✓   │        │          │  ✓   │   ✓    │          │
└─────────────┴───────────┴─────────┴──────────┴────────┴──────┴────────┴───────┴────────┴──────────┴──────┴────────┴──────────┘
```

Note: Simons also receives all 9 quant metrics (volatility, mean reversion, relative strength, correlation, liquidity, return distribution, statistical anomalies). Shiller also receives narrative_momentum.
