# Jim Simons & Robert Shiller Expert Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Add Jim Simons (quant) and Robert Shiller (behavioral economist) as expert perspectives, expanding from 7 to 9 gurus with full Python metrics integration.

**Architecture:** Two new metric modules (`quant_metrics.py`, `behavioral_metrics.py`) feed into the existing `ComprehensiveAnalysis` dataclass via `orchestrator.py`. Two new expert prompts follow the identical pattern as existing experts. SKILL.md orchestration updated for 9-expert parallel dispatch.

**Tech Stack:** Python 3 (stdlib only: `math`, `statistics`), Markdown expert prompts, existing `MetricResult` dataclass pattern.

**Design Doc:** `docs/plans/2026-02-16-simons-shiller-experts-design.md`

---

## Task 1: Add Benchmark Price Data to CompanyData

**Files:**
- Modify: `financial-researcher/processing/data_extractor.py`

**Step 1: Add BenchmarkData dataclass and sector ETF mapping after InsiderData class (line ~170)**

Add after the `InsiderData` dataclass definition:

```python
@dataclass
class BenchmarkData:
    """Benchmark price data for relative analysis."""
    spy_prices: List[Dict[str, Any]] = field(default_factory=list)  # S&P 500
    sector_etf_ticker: str = ""
    sector_etf_prices: List[Dict[str, Any]] = field(default_factory=list)
    vix_prices: List[Dict[str, Any]] = field(default_factory=list)


SECTOR_TO_ETF = {
    "technology": "XLK",
    "information technology": "XLK",
    "healthcare": "XLV",
    "health care": "XLV",
    "financials": "XLF",
    "consumer discretionary": "XLY",
    "consumer staples": "XLP",
    "industrials": "XLI",
    "energy": "XLE",
    "materials": "XLB",
    "utilities": "XLU",
    "real estate": "XLRE",
    "communication services": "XLC",
    "telecommunications": "XLC",
}


def get_sector_etf(sector: str) -> str:
    """Map company sector to corresponding sector ETF ticker."""
    return SECTOR_TO_ETF.get(sector.lower().strip(), "SPY")
```

**Step 2: Add benchmark field to CompanyData dataclass**

In the `CompanyData` class, add after the `eps_estimates` field:

```python
    # Benchmark data (for relative/quant analysis)
    benchmarks: BenchmarkData = field(default_factory=BenchmarkData)
```

**Step 3: Update extract_company_data function signature and body**

Add new parameters to `extract_company_data()`:

```python
def extract_company_data(
    ticker: str,
    income_statements: List[Dict[str, Any]],
    balance_sheets: List[Dict[str, Any]],
    cash_flows: List[Dict[str, Any]],
    metrics: Dict[str, Any],
    price_data: Dict[str, Any],
    holdings_by_investor: Dict[str, List[Dict[str, Any]]] = None,
    insider_trades: List[Dict[str, Any]] = None,
    analyst_estimates: List[Dict[str, Any]] = None,
    company_facts: Dict[str, Any] = None,
    # NEW: Benchmark data for quant analysis
    spy_prices: List[Dict[str, Any]] = None,
    sector_etf_prices: List[Dict[str, Any]] = None,
    sector_etf_ticker: str = "",
    vix_prices: List[Dict[str, Any]] = None,
) -> CompanyData:
```

Add at the end of the function, before `return company`:

```python
    # Extract benchmark data
    company.benchmarks = BenchmarkData(
        spy_prices=spy_prices or [],
        sector_etf_ticker=sector_etf_ticker,
        sector_etf_prices=sector_etf_prices or [],
        vix_prices=vix_prices or [],
    )
```

**Step 4: Run existing tests to verify no regression**

Run: `cd /Users/leozhang/Documents/GitHub/FAskills/financial-researcher && python -m processing.test_pipeline`
Expected: All existing tests pass (new params have defaults).

**Step 5: Commit**

```bash
git add financial-researcher/processing/data_extractor.py
git commit -m "feat: add benchmark price data (SPY, sector ETF, VIX) to CompanyData"
```

---

## Task 2: Create quant_metrics.py — Momentum, Volatility, Mean Reversion

**Files:**
- Create: `financial-researcher/processing/quant_metrics.py`

**Step 1: Create file with helper functions and first 3 metric functions**

```python
"""
Quantitative Factor Metrics for Jim Simons Expert Analysis

Statistical and factor-based analysis using price/volume data
and fundamental metrics. All functions return MetricResult.

No external dependencies — uses Python stdlib (math, statistics).
"""

from typing import List, Dict, Any, Optional
from statistics import mean, stdev, median
import math

from .metrics_calculator import MetricResult


# =============================================================================
# HELPERS
# =============================================================================

def _extract_closes(prices: List[Dict[str, Any]]) -> List[float]:
    """Extract close prices from price history, oldest first."""
    sorted_prices = sorted(prices, key=lambda p: p.get('date', p.get('time', '')))
    return [p.get('close', p.get('price', 0)) for p in sorted_prices if p.get('close', p.get('price', 0)) > 0]


def _extract_volumes(prices: List[Dict[str, Any]]) -> List[float]:
    """Extract volumes from price history, oldest first."""
    sorted_prices = sorted(prices, key=lambda p: p.get('date', p.get('time', '')))
    return [p.get('volume', 0) for p in sorted_prices]


def _returns(prices: List[float]) -> List[float]:
    """Calculate daily returns from price series."""
    return [(prices[i] / prices[i-1]) - 1 for i in range(1, len(prices)) if prices[i-1] != 0]


def _sma(values: List[float], window: int) -> float:
    """Simple moving average of last `window` values."""
    if len(values) < window:
        return mean(values) if values else 0
    return mean(values[-window:])


def _ema(values: List[float], window: int) -> float:
    """Exponential moving average."""
    if not values:
        return 0
    multiplier = 2 / (window + 1)
    ema_val = values[0]
    for price in values[1:]:
        ema_val = (price * multiplier) + (ema_val * (1 - multiplier))
    return ema_val


def _rsi(prices: List[float], period: int = 14) -> float:
    """Relative Strength Index."""
    if len(prices) < period + 1:
        return 50.0  # Neutral default
    rets = _returns(prices[-(period + 1):])
    gains = [r for r in rets if r > 0]
    losses = [-r for r in rets if r < 0]
    avg_gain = mean(gains) if gains else 0
    avg_loss = mean(losses) if losses else 0.0001
    rs = avg_gain / avg_loss
    return 100 - (100 / (1 + rs))


# =============================================================================
# METRIC FUNCTIONS
# =============================================================================

def momentum_score(
    prices: List[Dict[str, Any]],
) -> MetricResult:
    """
    Price momentum analysis (Jegadeesh & Titman).

    Calculates:
    - 12-month momentum (skip last month)
    - 6-month momentum
    - 3-month momentum
    - 1-month momentum (short-term reversal signal)
    - Momentum persistence (consistency of monthly returns)

    Medium-term focus: 1-6 month horizon.
    """
    closes = _extract_closes(prices)
    flags = []

    if len(closes) < 252:
        return MetricResult(
            value=0, interpretation="Insufficient price data for momentum analysis",
            flags=["Need at least 252 trading days"], data_quality=0.3
        )

    current = closes[-1]

    # Momentum calculations
    mom_12m_skip1m = (closes[-22] / closes[-252]) - 1 if len(closes) >= 252 else 0  # 12m skip last month
    mom_6m = (current / closes[-126]) - 1 if len(closes) >= 126 else 0
    mom_3m = (current / closes[-63]) - 1 if len(closes) >= 63 else 0
    mom_1m = (current / closes[-22]) - 1 if len(closes) >= 22 else 0

    # Momentum persistence: % of positive months in last 12
    monthly_returns = []
    for i in range(12):
        start_idx = -(i + 1) * 22
        end_idx = -i * 22 if i > 0 else None
        if abs(start_idx) <= len(closes):
            month_start = closes[start_idx]
            month_end = closes[end_idx] if end_idx else closes[-1]
            if month_start > 0:
                monthly_returns.append((month_end / month_start) - 1)

    persistence = sum(1 for r in monthly_returns if r > 0) / len(monthly_returns) if monthly_returns else 0.5

    # Composite momentum score: weighted blend
    composite = (mom_12m_skip1m * 0.4) + (mom_6m * 0.3) + (mom_3m * 0.2) + (mom_1m * 0.1)

    components = {
        "momentum_12m_skip1m": round(mom_12m_skip1m * 100, 2),
        "momentum_6m": round(mom_6m * 100, 2),
        "momentum_3m": round(mom_3m * 100, 2),
        "momentum_1m": round(mom_1m * 100, 2),
        "persistence": round(persistence * 100, 1),
        "composite": round(composite * 100, 2),
    }

    # Interpretation
    if composite > 0.20:
        interpretation = "Strong positive momentum — trend following favored"
    elif composite > 0.05:
        interpretation = "Moderate positive momentum"
    elif composite > -0.05:
        interpretation = "Neutral momentum — no clear trend"
    elif composite > -0.20:
        interpretation = "Moderate negative momentum"
    else:
        interpretation = "Strong negative momentum — trend is down"

    # Flags
    if mom_1m < -0.10 and mom_12m_skip1m > 0.15:
        flags.append("Short-term reversal in a long-term uptrend — potential buying opportunity")
    if mom_1m > 0.10 and mom_12m_skip1m < -0.15:
        flags.append("Short-term bounce in a long-term downtrend — potential dead cat bounce")
    if persistence > 0.75:
        flags.append(f"High momentum persistence ({persistence*100:.0f}% positive months) — trend is strong")
    if persistence < 0.25:
        flags.append(f"Persistent decline ({(1-persistence)*100:.0f}% negative months)")

    return MetricResult(
        value=round(composite * 100, 2),
        interpretation=interpretation,
        components=components,
        flags=flags,
    )


def volatility_metrics(
    prices: List[Dict[str, Any]],
    vix_prices: List[Dict[str, Any]] = None,
) -> MetricResult:
    """
    Volatility regime analysis.

    Calculates:
    - Realized volatility (20d, 60d, 252d annualized)
    - Volatility regime (high/normal/low relative to own history)
    - Vol-of-vol (stability of volatility)
    - VIX context (if available)
    """
    closes = _extract_closes(prices)
    flags = []

    if len(closes) < 60:
        return MetricResult(
            value=0, interpretation="Insufficient data for volatility analysis",
            flags=["Need at least 60 trading days"], data_quality=0.3
        )

    rets = _returns(closes)
    annualize = math.sqrt(252)

    # Realized volatility at different windows
    vol_20d = stdev(rets[-20:]) * annualize if len(rets) >= 20 else 0
    vol_60d = stdev(rets[-60:]) * annualize if len(rets) >= 60 else 0
    vol_252d = stdev(rets[-252:]) * annualize if len(rets) >= 252 else vol_60d

    # Vol regime: compare short-term vol to long-term
    vol_ratio = vol_20d / vol_252d if vol_252d > 0 else 1.0

    # Vol-of-vol: rolling 20d vol measured over 60d windows
    if len(rets) >= 120:
        rolling_vols = []
        for i in range(0, len(rets) - 20, 5):  # Every 5 days
            window = rets[i:i+20]
            if len(window) >= 20:
                rolling_vols.append(stdev(window) * annualize)
        vol_of_vol = stdev(rolling_vols) if len(rolling_vols) >= 2 else 0
    else:
        vol_of_vol = 0

    # VIX context
    vix_current = None
    if vix_prices:
        vix_closes = _extract_closes(vix_prices)
        if vix_closes:
            vix_current = vix_closes[-1]

    components = {
        "vol_20d": round(vol_20d * 100, 2),
        "vol_60d": round(vol_60d * 100, 2),
        "vol_252d": round(vol_252d * 100, 2),
        "vol_ratio_20d_vs_252d": round(vol_ratio, 2),
        "vol_of_vol": round(vol_of_vol * 100, 2),
        "vix_current": round(vix_current, 2) if vix_current else None,
    }

    # Regime classification
    if vol_ratio > 1.5:
        regime = "HIGH"
        interpretation = f"High volatility regime — 20d vol ({vol_20d*100:.1f}%) well above normal ({vol_252d*100:.1f}%)"
        flags.append("Elevated volatility — larger position sizing risk")
    elif vol_ratio > 1.15:
        regime = "ELEVATED"
        interpretation = f"Elevated volatility — 20d vol ({vol_20d*100:.1f}%) above normal"
    elif vol_ratio < 0.65:
        regime = "COMPRESSED"
        interpretation = f"Compressed volatility — potential breakout setup"
        flags.append("Vol compression often precedes large moves — direction unclear")
    elif vol_ratio < 0.85:
        regime = "LOW"
        interpretation = f"Low volatility — calm market conditions"
    else:
        regime = "NORMAL"
        interpretation = f"Normal volatility regime ({vol_20d*100:.1f}% annualized)"

    components["regime"] = regime

    if vix_current and vix_current > 30:
        flags.append(f"VIX at {vix_current:.1f} — market-wide fear elevated")
    elif vix_current and vix_current < 15:
        flags.append(f"VIX at {vix_current:.1f} — market complacency, low hedging demand")

    return MetricResult(
        value=round(vol_20d * 100, 2),
        interpretation=interpretation,
        components=components,
        flags=flags,
    )


def mean_reversion_signals(
    prices: List[Dict[str, Any]],
) -> MetricResult:
    """
    Mean reversion signal detection.

    Calculates:
    - Z-score vs 50-day and 200-day moving average
    - RSI (14-day)
    - Bollinger Band position (% B)
    - Distance from 52-week high/low
    """
    closes = _extract_closes(prices)
    flags = []

    if len(closes) < 50:
        return MetricResult(
            value=0, interpretation="Insufficient data for mean reversion analysis",
            flags=["Need at least 50 trading days"], data_quality=0.3
        )

    current = closes[-1]

    # Moving averages
    sma_50 = _sma(closes, 50)
    sma_200 = _sma(closes, 200) if len(closes) >= 200 else sma_50

    # Z-scores vs MAs
    rets_50 = _returns(closes[-51:]) if len(closes) >= 51 else _returns(closes)
    std_50 = stdev(closes[-50:]) if len(closes) >= 50 else stdev(closes)
    z_vs_50 = (current - sma_50) / std_50 if std_50 > 0 else 0

    std_200 = stdev(closes[-200:]) if len(closes) >= 200 else std_50
    z_vs_200 = (current - sma_200) / std_200 if std_200 > 0 else 0

    # RSI
    rsi_val = _rsi(closes)

    # Bollinger Bands (20-day, 2 std)
    bb_sma = _sma(closes, 20)
    bb_std = stdev(closes[-20:]) if len(closes) >= 20 else stdev(closes)
    bb_upper = bb_sma + 2 * bb_std
    bb_lower = bb_sma - 2 * bb_std
    bb_pct = (current - bb_lower) / (bb_upper - bb_lower) if (bb_upper - bb_lower) > 0 else 0.5

    # 52-week range position
    high_52w = max(closes[-252:]) if len(closes) >= 252 else max(closes)
    low_52w = min(closes[-252:]) if len(closes) >= 252 else min(closes)
    range_position = (current - low_52w) / (high_52w - low_52w) if (high_52w - low_52w) > 0 else 0.5
    dist_from_high = (current / high_52w) - 1 if high_52w > 0 else 0

    components = {
        "z_score_vs_50dma": round(z_vs_50, 2),
        "z_score_vs_200dma": round(z_vs_200, 2),
        "rsi_14": round(rsi_val, 1),
        "bollinger_pct_b": round(bb_pct * 100, 1),
        "range_52w_position": round(range_position * 100, 1),
        "distance_from_52w_high": round(dist_from_high * 100, 2),
        "sma_50": round(sma_50, 2),
        "sma_200": round(sma_200, 2),
    }

    # Composite mean reversion score: -100 (oversold) to +100 (overbought)
    mr_score = (
        (z_vs_50 * 20) +  # Z-score contribution
        ((rsi_val - 50) * 0.8) +  # RSI contribution (centered on 50)
        ((bb_pct - 0.5) * 40) +  # Bollinger contribution
        ((range_position - 0.5) * 20)  # Range position contribution
    )
    mr_score = max(-100, min(100, mr_score))

    # Interpretation
    if mr_score > 50:
        interpretation = "Strongly overbought — high mean reversion probability to downside"
        flags.append("Multiple overbought signals aligned — caution on new longs")
    elif mr_score > 20:
        interpretation = "Moderately overbought — extended but not extreme"
    elif mr_score < -50:
        interpretation = "Strongly oversold — high mean reversion probability to upside"
        flags.append("Multiple oversold signals aligned — potential buying opportunity")
    elif mr_score < -20:
        interpretation = "Moderately oversold — pullback may present opportunity"
    else:
        interpretation = "Neutral — no strong mean reversion signal"

    # Specific flags
    if rsi_val > 70:
        flags.append(f"RSI overbought at {rsi_val:.0f}")
    elif rsi_val < 30:
        flags.append(f"RSI oversold at {rsi_val:.0f}")
    if current > sma_50 > sma_200:
        flags.append("Golden cross — price > 50 DMA > 200 DMA (bullish structure)")
    elif current < sma_50 < sma_200:
        flags.append("Death cross — price < 50 DMA < 200 DMA (bearish structure)")

    return MetricResult(
        value=round(mr_score, 1),
        interpretation=interpretation,
        components=components,
        flags=flags,
    )
```

**Step 2: Run a quick syntax check**

Run: `cd /Users/leozhang/Documents/GitHub/FAskills/financial-researcher && python -c "from processing.quant_metrics import momentum_score, volatility_metrics, mean_reversion_signals; print('Import OK')"`
Expected: `Import OK`

**Step 3: Commit**

```bash
git add financial-researcher/processing/quant_metrics.py
git commit -m "feat: add quant_metrics.py — momentum, volatility, mean reversion"
```

---

## Task 3: Add Remaining Quant Metrics — Factors, Anomalies, Relative Strength, Correlation, Liquidity, Return Distribution

**Files:**
- Modify: `financial-researcher/processing/quant_metrics.py`

**Step 1: Add the remaining 6 metric functions**

Append to `quant_metrics.py`:

```python
def factor_exposure(
    pe_ratio: float = None,
    pb_ratio: float = None,
    roe: float = None,
    accrual_ratio: float = None,
    market_cap: float = None,
    momentum_12m: float = None,
) -> MetricResult:
    """
    Multi-factor exposure analysis.

    Scores exposure to academic risk factors:
    - Value (low P/E, low P/B)
    - Quality (high ROE, low accruals)
    - Size (small cap premium)
    - Momentum (12-month return)

    Each factor scored -2 (strong negative) to +2 (strong positive).
    """
    components = {}
    flags = []

    # Value factor
    value_score = 0
    if pe_ratio is not None and pe_ratio > 0:
        if pe_ratio < 12:
            value_score = 2
        elif pe_ratio < 18:
            value_score = 1
        elif pe_ratio > 35:
            value_score = -2
        elif pe_ratio > 25:
            value_score = -1
    if pb_ratio is not None and pb_ratio > 0:
        if pb_ratio < 1.5:
            value_score = min(2, value_score + 1)
        elif pb_ratio > 5:
            value_score = max(-2, value_score - 1)
    components["value_factor"] = value_score

    # Quality factor
    quality_score = 0
    if roe is not None:
        if roe > 0.20:
            quality_score = 2
        elif roe > 0.12:
            quality_score = 1
        elif roe < 0:
            quality_score = -2
        elif roe < 0.05:
            quality_score = -1
    if accrual_ratio is not None:
        if abs(accrual_ratio) < 0.05:
            quality_score = min(2, quality_score + 1)
        elif abs(accrual_ratio) > 0.15:
            quality_score = max(-2, quality_score - 1)
    components["quality_factor"] = quality_score

    # Size factor
    size_score = 0
    if market_cap is not None:
        if market_cap < 2e9:
            size_score = 2  # Small cap
        elif market_cap < 10e9:
            size_score = 1  # Mid cap
        elif market_cap > 200e9:
            size_score = -1  # Mega cap (less size premium)
    components["size_factor"] = size_score

    # Momentum factor
    mom_score = 0
    if momentum_12m is not None:
        if momentum_12m > 0.30:
            mom_score = 2
        elif momentum_12m > 0.10:
            mom_score = 1
        elif momentum_12m < -0.30:
            mom_score = -2
        elif momentum_12m < -0.10:
            mom_score = -1
    components["momentum_factor"] = mom_score

    # Composite
    composite = value_score + quality_score + size_score + mom_score
    components["composite_factor_score"] = composite

    if composite >= 4:
        interpretation = "Strong multi-factor tailwind — value, quality, and momentum aligned"
    elif composite >= 2:
        interpretation = "Positive factor exposure — favorable characteristics"
    elif composite <= -4:
        interpretation = "Strong multi-factor headwind — expensive, low quality, poor momentum"
    elif composite <= -2:
        interpretation = "Negative factor exposure — unfavorable characteristics"
    else:
        interpretation = "Neutral factor exposure — mixed signals"

    # Crowding flags
    if value_score >= 2 and mom_score >= 2:
        flags.append("Value + momentum aligned — historically strong signal")
    if value_score <= -2 and mom_score >= 2:
        flags.append("Expensive with strong momentum — growth/momentum trade, vulnerable to rotation")
    if quality_score <= -1 and mom_score >= 2:
        flags.append("Low quality with high momentum — potential blow-up risk")

    return MetricResult(
        value=composite,
        interpretation=interpretation,
        components=components,
        flags=flags,
    )


def statistical_anomalies(
    prices: List[Dict[str, Any]],
    earnings_values: List[float] = None,
) -> MetricResult:
    """
    Statistical anomaly detection in return distribution.

    Detects:
    - Non-normal return distribution (skewness, kurtosis)
    - Unusual volume patterns
    - Price-earnings divergence
    """
    closes = _extract_closes(prices)
    volumes = _extract_volumes(prices)
    flags = []

    if len(closes) < 60:
        return MetricResult(
            value=0, interpretation="Insufficient data for anomaly detection",
            flags=["Need at least 60 trading days"], data_quality=0.3
        )

    rets = _returns(closes)
    n = len(rets)

    # Skewness
    avg = mean(rets)
    std = stdev(rets)
    if std > 0 and n >= 30:
        skewness = sum((r - avg) ** 3 for r in rets) / (n * std ** 3)
        kurtosis = sum((r - avg) ** 4 for r in rets) / (n * std ** 4) - 3  # Excess kurtosis
    else:
        skewness = 0
        kurtosis = 0

    # Volume anomaly: recent volume vs historical
    if len(volumes) >= 60 and any(v > 0 for v in volumes):
        recent_vol = mean(volumes[-20:]) if volumes[-20:] else 0
        historical_vol = mean(volumes[-252:]) if len(volumes) >= 252 else mean(volumes)
        volume_ratio = recent_vol / historical_vol if historical_vol > 0 else 1.0
    else:
        volume_ratio = 1.0

    # Price-earnings divergence (if earnings provided)
    pe_divergence = None
    if earnings_values and len(earnings_values) >= 3 and len(closes) >= 252:
        # Compare price change to earnings change
        price_change_1yr = (closes[-1] / closes[-252]) - 1 if len(closes) >= 252 else 0
        earnings_change = (earnings_values[-1] / earnings_values[-2]) - 1 if earnings_values[-2] != 0 else 0
        pe_divergence = price_change_1yr - earnings_change

    # Anomaly score: 0 = normal, higher = more anomalous
    anomaly_score = 0
    anomaly_score += min(abs(skewness), 3)  # Skewness contribution
    anomaly_score += min(abs(kurtosis) / 2, 3)  # Kurtosis contribution
    anomaly_score += min(abs(volume_ratio - 1) * 2, 2)  # Volume contribution
    if pe_divergence is not None:
        anomaly_score += min(abs(pe_divergence), 2)  # Divergence contribution

    components = {
        "skewness": round(skewness, 3),
        "excess_kurtosis": round(kurtosis, 3),
        "volume_ratio_recent_vs_historical": round(volume_ratio, 2),
        "price_earnings_divergence": round(pe_divergence * 100, 2) if pe_divergence is not None else None,
        "anomaly_score": round(anomaly_score, 2),
    }

    # Flags
    if skewness < -0.5:
        flags.append(f"Negative skew ({skewness:.2f}) — more frequent large drops than gains")
    elif skewness > 0.5:
        flags.append(f"Positive skew ({skewness:.2f}) — occasional large gains")
    if kurtosis > 3:
        flags.append(f"Fat tails (excess kurtosis {kurtosis:.1f}) — extreme moves more likely than normal")
    if volume_ratio > 2.0:
        flags.append(f"Abnormal volume ({volume_ratio:.1f}x normal) — increased attention or distribution")
    elif volume_ratio < 0.5:
        flags.append(f"Low volume ({volume_ratio:.1f}x normal) — reduced liquidity/interest")
    if pe_divergence is not None and abs(pe_divergence) > 0.30:
        if pe_divergence > 0:
            flags.append(f"Price outrunning earnings by {pe_divergence*100:.0f}pp — multiple expansion")
        else:
            flags.append(f"Earnings outrunning price by {abs(pe_divergence)*100:.0f}pp — potential value")

    if anomaly_score > 5:
        interpretation = "Multiple statistical anomalies detected — unusual market behavior"
    elif anomaly_score > 3:
        interpretation = "Some anomalies present — warrants attention"
    else:
        interpretation = "Return distribution roughly normal — no major anomalies"

    return MetricResult(
        value=round(anomaly_score, 2),
        interpretation=interpretation,
        components=components,
        flags=flags,
    )


def sector_relative_strength(
    stock_prices: List[Dict[str, Any]],
    sector_etf_prices: List[Dict[str, Any]],
    spy_prices: List[Dict[str, Any]],
) -> MetricResult:
    """
    Relative strength analysis: stock vs sector ETF vs S&P 500.

    Calculates relative outperformance over 1m, 3m, 6m, 12m.
    """
    stock = _extract_closes(stock_prices)
    sector = _extract_closes(sector_etf_prices)
    spy = _extract_closes(spy_prices)
    flags = []

    min_len = min(len(stock), len(sector), len(spy))
    if min_len < 22:
        return MetricResult(
            value=0, interpretation="Insufficient data for relative strength",
            flags=["Need at least 22 trading days of benchmark data"], data_quality=0.3
        )

    # Align lengths (use most recent data)
    stock = stock[-min_len:]
    sector = sector[-min_len:]
    spy = spy[-min_len:]

    def rel_perf(a, b, days):
        """Relative performance over N days."""
        if len(a) < days or len(b) < days:
            return 0
        return ((a[-1] / a[-days]) - 1) - ((b[-1] / b[-days]) - 1)

    components = {}
    for label, days in [("1m", 22), ("3m", 63), ("6m", 126), ("12m", 252)]:
        if min_len >= days:
            components[f"vs_sector_{label}"] = round(rel_perf(stock, sector, days) * 100, 2)
            components[f"vs_spy_{label}"] = round(rel_perf(stock, spy, days) * 100, 2)
        else:
            components[f"vs_sector_{label}"] = None
            components[f"vs_spy_{label}"] = None

    # Composite: weighted average of available periods (recent weighted more)
    weights = {"1m": 0.1, "3m": 0.2, "6m": 0.3, "12m": 0.4}
    vs_spy_composite = 0
    total_weight = 0
    for label, w in weights.items():
        val = components.get(f"vs_spy_{label}")
        if val is not None:
            vs_spy_composite += val * w
            total_weight += w
    vs_spy_composite = vs_spy_composite / total_weight if total_weight > 0 else 0

    components["vs_spy_composite"] = round(vs_spy_composite, 2)

    if vs_spy_composite > 15:
        interpretation = "Strong outperformer — significant leadership vs market"
    elif vs_spy_composite > 5:
        interpretation = "Outperforming market — positive relative strength"
    elif vs_spy_composite < -15:
        interpretation = "Strong underperformer — lagging market significantly"
    elif vs_spy_composite < -5:
        interpretation = "Underperforming market — negative relative strength"
    else:
        interpretation = "In line with market — neutral relative strength"

    # Flags
    vs_sector_3m = components.get("vs_sector_3m", 0) or 0
    vs_sector_12m = components.get("vs_sector_12m", 0) or 0
    if vs_sector_3m > 10:
        flags.append(f"Outperforming sector by {vs_sector_3m:.1f}pp over 3 months — sector leadership")
    if vs_sector_3m < -10:
        flags.append(f"Underperforming sector by {abs(vs_sector_3m):.1f}pp over 3 months — sector laggard")
    if vs_spy_composite > 10 and vs_sector_12m and vs_sector_12m > 10:
        flags.append("Outperforming both market AND sector — strong stock-specific strength")

    return MetricResult(
        value=round(vs_spy_composite, 2),
        interpretation=interpretation,
        components=components,
        flags=flags,
    )


def correlation_regime(
    stock_prices: List[Dict[str, Any]],
    spy_prices: List[Dict[str, Any]],
) -> MetricResult:
    """
    Correlation and beta analysis vs S&P 500.

    Calculates:
    - Rolling correlation (30d, 90d, 252d)
    - Beta (90d, 252d)
    - Correlation breakdown detection
    """
    stock = _extract_closes(stock_prices)
    spy = _extract_closes(spy_prices)
    flags = []

    min_len = min(len(stock), len(spy))
    if min_len < 30:
        return MetricResult(
            value=0, interpretation="Insufficient data for correlation analysis",
            flags=["Need at least 30 trading days"], data_quality=0.3
        )

    stock = stock[-min_len:]
    spy = spy[-min_len:]

    stock_rets = _returns(stock)
    spy_rets = _returns(spy)
    min_rets = min(len(stock_rets), len(spy_rets))
    stock_rets = stock_rets[-min_rets:]
    spy_rets = spy_rets[-min_rets:]

    def calc_corr(a, b, n):
        if len(a) < n or len(b) < n:
            return None
        x, y = a[-n:], b[-n:]
        mx, my = mean(x), mean(y)
        sx, sy = stdev(x), stdev(y)
        if sx == 0 or sy == 0:
            return 0
        cov = sum((xi - mx) * (yi - my) for xi, yi in zip(x, y)) / (n - 1)
        return cov / (sx * sy)

    def calc_beta(stock_r, mkt_r, n):
        if len(stock_r) < n or len(mkt_r) < n:
            return None
        x, y = mkt_r[-n:], stock_r[-n:]
        mx = mean(x)
        var_x = sum((xi - mx) ** 2 for xi in x) / (n - 1)
        if var_x == 0:
            return 0
        cov = sum((xi - mx) * (yi - mean(y)) for xi, yi in zip(x, y)) / (n - 1)
        return cov / var_x

    corr_30d = calc_corr(stock_rets, spy_rets, 30)
    corr_90d = calc_corr(stock_rets, spy_rets, 90)
    corr_252d = calc_corr(stock_rets, spy_rets, 252)
    beta_90d = calc_beta(stock_rets, spy_rets, 90)
    beta_252d = calc_beta(stock_rets, spy_rets, 252)

    components = {
        "correlation_30d": round(corr_30d, 3) if corr_30d is not None else None,
        "correlation_90d": round(corr_90d, 3) if corr_90d is not None else None,
        "correlation_252d": round(corr_252d, 3) if corr_252d is not None else None,
        "beta_90d": round(beta_90d, 2) if beta_90d is not None else None,
        "beta_252d": round(beta_252d, 2) if beta_252d is not None else None,
    }

    # Correlation breakdown detection
    if corr_30d is not None and corr_252d is not None:
        corr_change = corr_30d - corr_252d
        components["correlation_change_short_vs_long"] = round(corr_change, 3)
        if abs(corr_change) > 0.3:
            flags.append(f"Correlation regime shift: 30d={corr_30d:.2f} vs 252d={corr_252d:.2f} — stock decoupling from market")

    primary_corr = corr_90d if corr_90d is not None else (corr_30d or 0)

    if primary_corr > 0.8:
        interpretation = f"High market correlation ({primary_corr:.2f}) — moves with S&P 500"
    elif primary_corr > 0.5:
        interpretation = f"Moderate market correlation ({primary_corr:.2f})"
    elif primary_corr > 0.2:
        interpretation = f"Low market correlation ({primary_corr:.2f}) — partial diversifier"
    else:
        interpretation = f"Very low/negative correlation ({primary_corr:.2f}) — strong diversifier"

    if beta_90d is not None:
        if beta_90d > 1.5:
            flags.append(f"High beta ({beta_90d:.2f}) — amplifies market moves")
        elif beta_90d < 0.5:
            flags.append(f"Low beta ({beta_90d:.2f}) — defensive characteristics")

    return MetricResult(
        value=round(primary_corr, 3) if primary_corr else 0,
        interpretation=interpretation,
        components=components,
        flags=flags,
    )


def liquidity_metrics(
    prices: List[Dict[str, Any]],
) -> MetricResult:
    """
    Market microstructure and liquidity analysis.

    Calculates:
    - Amihud illiquidity ratio
    - High-low spread proxy (Corwin-Schultz)
    - Volume trend
    - Abnormal volume detection
    """
    closes = _extract_closes(prices)
    volumes = _extract_volumes(prices)
    flags = []

    if len(closes) < 22 or not any(v > 0 for v in volumes):
        return MetricResult(
            value=0, interpretation="Insufficient data for liquidity analysis",
            flags=["Need at least 22 trading days with volume"], data_quality=0.3
        )

    rets = _returns(closes)

    # Amihud illiquidity: average |return| / volume (higher = less liquid)
    amihud_values = []
    for i in range(min(len(rets), len(volumes) - 1)):
        vol = volumes[i + 1]
        if vol > 0:
            amihud_values.append(abs(rets[i]) / vol)
    amihud = mean(amihud_values) * 1e6 if amihud_values else 0  # Scale for readability

    # High-low spread proxy
    sorted_prices = sorted(prices, key=lambda p: p.get('date', p.get('time', '')))
    spreads = []
    for p in sorted_prices:
        high = p.get('high', 0)
        low = p.get('low', 0)
        if high > 0 and low > 0:
            spreads.append((high - low) / ((high + low) / 2))
    avg_spread = mean(spreads[-20:]) if len(spreads) >= 20 else (mean(spreads) if spreads else 0)

    # Volume trend: 20-day avg vs 60-day avg
    vol_20 = mean(volumes[-20:]) if len(volumes) >= 20 else mean(volumes)
    vol_60 = mean(volumes[-60:]) if len(volumes) >= 60 else vol_20
    vol_trend = (vol_20 / vol_60) - 1 if vol_60 > 0 else 0

    # Abnormal volume: current vs 252-day average
    vol_252 = mean(volumes[-252:]) if len(volumes) >= 252 else mean(volumes)
    vol_ratio = vol_20 / vol_252 if vol_252 > 0 else 1.0

    components = {
        "amihud_illiquidity": round(amihud, 4),
        "avg_spread_pct": round(avg_spread * 100, 3),
        "volume_trend_20d_vs_60d": round(vol_trend * 100, 1),
        "volume_ratio_vs_252d": round(vol_ratio, 2),
        "avg_daily_volume_20d": round(vol_20, 0),
    }

    # Interpretation
    if amihud > 1.0:
        interpretation = "Low liquidity — significant price impact risk"
        flags.append("Illiquid stock — position sizing should be conservative")
    elif amihud > 0.1:
        interpretation = "Moderate liquidity"
    else:
        interpretation = "High liquidity — easy to trade in size"

    if vol_ratio > 2.0:
        flags.append(f"Volume surge ({vol_ratio:.1f}x normal) — heightened activity")
    if vol_trend > 0.50:
        flags.append(f"Volume trending up {vol_trend*100:.0f}% — increasing interest")
    elif vol_trend < -0.30:
        flags.append(f"Volume trending down {vol_trend*100:.0f}% — waning interest")

    return MetricResult(
        value=round(amihud, 4),
        interpretation=interpretation,
        components=components,
        flags=flags,
    )


def return_distribution(
    prices: List[Dict[str, Any]],
) -> MetricResult:
    """
    Full return distribution and tail risk analysis.

    Calculates:
    - Annualized return and Sharpe proxy (assuming 0% risk-free)
    - Max drawdown
    - CVaR (Expected Shortfall) at 5%
    - Calmar ratio (return / max drawdown)
    """
    closes = _extract_closes(prices)
    flags = []

    if len(closes) < 60:
        return MetricResult(
            value=0, interpretation="Insufficient data for return distribution",
            flags=["Need at least 60 trading days"], data_quality=0.3
        )

    rets = _returns(closes)
    annualize = 252

    # Annualized return
    total_return = (closes[-1] / closes[0]) - 1
    years = len(rets) / annualize
    annual_return = (1 + total_return) ** (1 / years) - 1 if years > 0 else 0

    # Annualized volatility and Sharpe proxy
    annual_vol = stdev(rets) * math.sqrt(annualize)
    sharpe = annual_return / annual_vol if annual_vol > 0 else 0

    # Max drawdown
    peak = closes[0]
    max_dd = 0
    for price in closes:
        if price > peak:
            peak = price
        dd = (price / peak) - 1
        if dd < max_dd:
            max_dd = dd

    # CVaR at 5% (average of worst 5% of daily returns)
    sorted_rets = sorted(rets)
    cutoff = max(1, int(len(sorted_rets) * 0.05))
    cvar_5 = mean(sorted_rets[:cutoff])

    # Calmar ratio
    calmar = annual_return / abs(max_dd) if max_dd != 0 else 0

    components = {
        "annual_return": round(annual_return * 100, 2),
        "annual_volatility": round(annual_vol * 100, 2),
        "sharpe_ratio": round(sharpe, 2),
        "max_drawdown": round(max_dd * 100, 2),
        "cvar_5pct": round(cvar_5 * 100, 3),
        "calmar_ratio": round(calmar, 2),
    }

    # Interpretation based on risk-adjusted returns
    if sharpe > 1.0:
        interpretation = f"Excellent risk-adjusted returns (Sharpe {sharpe:.2f})"
    elif sharpe > 0.5:
        interpretation = f"Good risk-adjusted returns (Sharpe {sharpe:.2f})"
    elif sharpe > 0:
        interpretation = f"Positive but weak risk-adjusted returns (Sharpe {sharpe:.2f})"
    else:
        interpretation = f"Negative risk-adjusted returns (Sharpe {sharpe:.2f})"

    if max_dd < -0.40:
        flags.append(f"Severe max drawdown ({max_dd*100:.1f}%) — high tail risk")
    elif max_dd < -0.25:
        flags.append(f"Significant drawdown ({max_dd*100:.1f}%)")
    if cvar_5 < -0.03:
        flags.append(f"High tail risk — worst 5% of days average {cvar_5*100:.2f}% loss")
    if calmar > 1.0:
        flags.append(f"Strong Calmar ratio ({calmar:.2f}) — good return per unit of drawdown")

    return MetricResult(
        value=round(sharpe, 2),
        interpretation=interpretation,
        components=components,
        flags=flags,
    )
```

**Step 2: Verify all 9 functions import**

Run: `cd /Users/leozhang/Documents/GitHub/FAskills/financial-researcher && python -c "from processing.quant_metrics import momentum_score, volatility_metrics, mean_reversion_signals, factor_exposure, statistical_anomalies, sector_relative_strength, correlation_regime, liquidity_metrics, return_distribution; print('All 9 quant metrics import OK')"`
Expected: `All 9 quant metrics import OK`

**Step 3: Commit**

```bash
git add financial-researcher/processing/quant_metrics.py
git commit -m "feat: add remaining quant metrics — factors, anomalies, relative strength, correlation, liquidity, returns"
```

---

## Task 4: Create behavioral_metrics.py — CAPE, Bubble Indicators, Narrative Momentum

**Files:**
- Create: `financial-researcher/processing/behavioral_metrics.py`

**Step 1: Create file with all 3 Shiller metric functions**

```python
"""
Behavioral Economics Metrics for Robert Shiller Expert Analysis

Long-term valuation and behavioral indicators:
- CAPE ratio (Cyclically-Adjusted P/E)
- Bubble detection indicators
- Narrative momentum scoring

No external dependencies — uses Python stdlib (math, statistics).
"""

from typing import List, Dict, Any, Optional
from statistics import mean, stdev, median
import math

from .metrics_calculator import MetricResult


def cape_ratio(
    earnings_history: List[float],
    current_price: float,
    shares_outstanding: float,
    inflation_adjustment: float = 1.0,
) -> MetricResult:
    """
    Cyclically-Adjusted Price-to-Earnings (CAPE/Shiller P/E).

    Uses up to 10 years of average real earnings to smooth cyclicality.
    Shiller's original research: CAPE is the single best predictor of
    long-term (10-year) stock returns.

    Args:
        earnings_history: Net income values, oldest first (up to 15 years)
        current_price: Current stock price
        shares_outstanding: Current shares outstanding
        inflation_adjustment: CPI adjustment factor (default 1.0 = no adjustment)
    """
    flags = []

    if not earnings_history or current_price <= 0 or shares_outstanding <= 0:
        return MetricResult(
            value=0, interpretation="Cannot calculate CAPE — missing data",
            flags=["Missing earnings history or price data"], data_quality=0.2
        )

    # Use up to 10 years of earnings
    earnings_to_use = earnings_history[-10:] if len(earnings_history) >= 10 else earnings_history
    years_used = len(earnings_to_use)

    # Calculate average real earnings
    avg_earnings = mean(earnings_to_use)
    eps_avg = avg_earnings / shares_outstanding if shares_outstanding > 0 else 0

    # Adjust for inflation if provided
    eps_avg_real = eps_avg / inflation_adjustment

    # CAPE ratio
    cape = current_price / eps_avg_real if eps_avg_real > 0 else 0

    # Excess CAPE yield (inverse of CAPE, as %)
    excess_cape_yield = (1 / cape * 100) if cape > 0 else 0

    # Implied long-term real return (rough approximation from Shiller's research)
    # Historically: 10-year real return ~ 1/CAPE * 100
    implied_10yr_return = excess_cape_yield

    components = {
        "cape_ratio": round(cape, 2),
        "excess_cape_yield": round(excess_cape_yield, 2),
        "implied_10yr_real_return": round(implied_10yr_return, 2),
        "years_of_earnings_used": years_used,
        "avg_eps_real": round(eps_avg_real, 2),
        "current_price": current_price,
    }

    # Interpretation using historical S&P 500 CAPE benchmarks
    # (applying same framework to individual stocks with caveat)
    if cape > 40:
        interpretation = f"Extremely elevated CAPE ({cape:.1f}) — historically associated with poor 10-year returns"
        flags.append(f"CAPE of {cape:.1f} exceeds dot-com peak levels (44) — extreme overvaluation risk")
    elif cape > 30:
        interpretation = f"High CAPE ({cape:.1f}) — above historical average, implies lower future returns"
        flags.append(f"CAPE above 30 — historically rare, expected real returns ~{implied_10yr_return:.1f}%/yr")
    elif cape > 20:
        interpretation = f"Moderate CAPE ({cape:.1f}) — near long-term average"
    elif cape > 12:
        interpretation = f"Below-average CAPE ({cape:.1f}) — historically favorable for long-term returns"
        flags.append(f"Below-average CAPE implies ~{implied_10yr_return:.1f}% real annual returns")
    elif cape > 0:
        interpretation = f"Low CAPE ({cape:.1f}) — historically associated with strong future returns"
        flags.append(f"Very low CAPE — historically best 10-year return periods")
    else:
        interpretation = "Negative or zero CAPE — sustained losses, not meaningful"
        flags.append("CAPE not meaningful with negative average earnings")

    if years_used < 10:
        flags.append(f"Only {years_used} years of earnings data — CAPE less reliable (ideally 10 years)")

    return MetricResult(
        value=round(cape, 2),
        interpretation=interpretation,
        components=components,
        flags=flags,
        data_quality=min(1.0, years_used / 10),
    )


def bubble_indicators(
    prices: List[Dict[str, Any]],
    earnings_history: List[float] = None,
) -> MetricResult:
    """
    Bubble detection indicators inspired by Shiller's research.

    Detects:
    - Price-to-trend deviation (is price far above its long-term trend?)
    - Price growth vs earnings growth divergence
    - Valuation percentile vs own history
    - Acceleration in price (prices rising at increasing rate)
    """
    from .quant_metrics import _extract_closes

    closes = _extract_closes(prices)
    flags = []

    if len(closes) < 252:
        return MetricResult(
            value=0, interpretation="Insufficient price history for bubble analysis",
            flags=["Need at least 1 year of price data"], data_quality=0.3
        )

    current = closes[-1]

    # 1. Price-to-trend deviation
    # Calculate log-linear trend and measure deviation
    n = len(closes)
    log_prices = [math.log(p) for p in closes if p > 0]
    if len(log_prices) >= 252:
        # Simple linear regression on log prices
        x_mean = (n - 1) / 2
        x_vals = list(range(n))
        y_mean = mean(log_prices)
        numerator = sum((x - x_mean) * (y - y_mean) for x, y in zip(x_vals, log_prices))
        denominator = sum((x - x_mean) ** 2 for x in x_vals)
        slope = numerator / denominator if denominator > 0 else 0
        intercept = y_mean - slope * x_mean
        trend_value = math.exp(intercept + slope * (n - 1))
        price_to_trend = (current / trend_value) - 1
    else:
        price_to_trend = 0

    # 2. Price growth vs earnings growth divergence
    pe_divergence = 0
    if earnings_history and len(earnings_history) >= 3:
        earnings_growth = (earnings_history[-1] / earnings_history[0]) - 1 if earnings_history[0] != 0 else 0
        price_growth = (closes[-1] / closes[0]) - 1 if closes[0] != 0 else 0
        pe_divergence = price_growth - earnings_growth

    # 3. Valuation percentile vs own history (using P/E proxy from price/earnings)
    val_percentile = 50.0  # Default
    if earnings_history and len(earnings_history) >= 5:
        # Rough PE at each year-end
        pe_history = []
        for i, earnings in enumerate(earnings_history):
            if earnings > 0 and i < len(closes) // 252:
                price_at_year = closes[min((i + 1) * 252 - 1, len(closes) - 1)]
                pe_history.append(price_at_year / (earnings / closes[-1] * current) if earnings != 0 else 0)
        if pe_history:
            current_pe = current / (earnings_history[-1] / 1) if earnings_history[-1] > 0 else 0
            val_percentile = sum(1 for pe in pe_history if pe < current_pe) / len(pe_history) * 100

    # 4. Price acceleration (is price growth accelerating?)
    if len(closes) >= 504:  # 2 years
        growth_yr1 = (closes[-252] / closes[-504]) - 1
        growth_yr2 = (closes[-1] / closes[-252]) - 1
        acceleration = growth_yr2 - growth_yr1
    elif len(closes) >= 252:
        growth_h1 = (closes[-126] / closes[-252]) - 1 if len(closes) >= 252 else 0
        growth_h2 = (closes[-1] / closes[-126]) - 1 if len(closes) >= 126 else 0
        acceleration = growth_h2 - growth_h1
    else:
        acceleration = 0

    # Composite bubble score: 0 (no bubble) to 100 (extreme bubble)
    bubble_score = 0
    bubble_score += max(0, min(30, price_to_trend * 50))  # Up to 30 from trend deviation
    bubble_score += max(0, min(25, pe_divergence * 25))  # Up to 25 from PE divergence
    bubble_score += max(0, min(25, (val_percentile - 50) / 2))  # Up to 25 from percentile
    bubble_score += max(0, min(20, acceleration * 40))  # Up to 20 from acceleration
    bubble_score = max(0, min(100, bubble_score))

    components = {
        "price_to_trend_deviation": round(price_to_trend * 100, 2),
        "price_vs_earnings_divergence": round(pe_divergence * 100, 2),
        "valuation_percentile_vs_history": round(val_percentile, 1),
        "price_acceleration": round(acceleration * 100, 2),
        "bubble_score": round(bubble_score, 1),
    }

    if bubble_score > 75:
        interpretation = f"High bubble risk ({bubble_score:.0f}/100) — multiple overvaluation signals"
        flags.append("Multiple bubble indicators elevated — historical parallels suggest caution")
    elif bubble_score > 50:
        interpretation = f"Elevated bubble risk ({bubble_score:.0f}/100) — extended but not extreme"
        flags.append("Valuations stretched — monitor for acceleration")
    elif bubble_score > 25:
        interpretation = f"Moderate bubble risk ({bubble_score:.0f}/100) — some elevation"
    else:
        interpretation = f"Low bubble risk ({bubble_score:.0f}/100) — no bubble characteristics"

    if price_to_trend > 0.50:
        flags.append(f"Price {price_to_trend*100:.0f}% above long-term trend — significant mean reversion risk")
    if acceleration > 0.20:
        flags.append(f"Price growth accelerating (+{acceleration*100:.0f}pp) — classic late-stage bubble behavior")

    return MetricResult(
        value=round(bubble_score, 1),
        interpretation=interpretation,
        components=components,
        flags=flags,
    )


def narrative_momentum_score(
    news_sentiment_positive: int = 0,
    news_sentiment_negative: int = 0,
    news_total: int = 0,
    analyst_estimates_high: float = None,
    analyst_estimates_low: float = None,
    analyst_estimates_mean: float = None,
) -> MetricResult:
    """
    Quantitative proxy for Shiller's narrative economics.

    Measures:
    - News sentiment ratio (positive vs negative coverage)
    - Analyst estimate dispersion (disagreement = narrative uncertainty)

    Higher score = stronger positive narrative momentum.
    """
    flags = []
    components = {}

    # News sentiment ratio
    if news_total > 0:
        pos_ratio = news_sentiment_positive / news_total
        neg_ratio = news_sentiment_negative / news_total
        sentiment_score = (pos_ratio - neg_ratio) * 100  # -100 to +100
        components["news_positive_ratio"] = round(pos_ratio * 100, 1)
        components["news_negative_ratio"] = round(neg_ratio * 100, 1)
        components["news_sentiment_score"] = round(sentiment_score, 1)
        components["news_total_articles"] = news_total
    else:
        sentiment_score = 0
        components["news_sentiment_score"] = 0

    # Analyst estimate dispersion
    dispersion = 0
    if analyst_estimates_high is not None and analyst_estimates_low is not None and analyst_estimates_mean:
        range_pct = (analyst_estimates_high - analyst_estimates_low) / abs(analyst_estimates_mean) if analyst_estimates_mean != 0 else 0
        dispersion = range_pct * 100
        components["analyst_estimate_dispersion"] = round(dispersion, 1)
        components["analyst_high"] = analyst_estimates_high
        components["analyst_low"] = analyst_estimates_low
        components["analyst_mean"] = analyst_estimates_mean

    # Composite narrative score: -100 (extreme negative narrative) to +100 (extreme positive)
    narrative_score = sentiment_score * 0.7  # 70% from sentiment
    # High dispersion reduces narrative strength (uncertainty)
    if dispersion > 50:
        narrative_score *= 0.7  # Dampen when analysts disagree

    components["composite_narrative_score"] = round(narrative_score, 1)

    if narrative_score > 50:
        interpretation = "Strong positive narrative — widespread bullish storytelling"
        flags.append("Dominant positive narrative — Shiller warns this often precedes disappointment")
    elif narrative_score > 20:
        interpretation = "Moderately positive narrative"
    elif narrative_score < -50:
        interpretation = "Strong negative narrative — widespread pessimism"
        flags.append("Extreme negative narrative — contrarian opportunity if fundamentals intact")
    elif narrative_score < -20:
        interpretation = "Moderately negative narrative"
    else:
        interpretation = "Neutral narrative — no dominant story"

    if dispersion > 80:
        flags.append(f"Extreme analyst disagreement (dispersion {dispersion:.0f}%) — high narrative uncertainty")
    elif dispersion > 50:
        flags.append(f"High analyst disagreement (dispersion {dispersion:.0f}%) — contested narrative")

    return MetricResult(
        value=round(narrative_score, 1),
        interpretation=interpretation,
        components=components,
        flags=flags,
        data_quality=0.5 if news_total < 5 else 1.0,
    )
```

**Step 2: Verify imports**

Run: `cd /Users/leozhang/Documents/GitHub/FAskills/financial-researcher && python -c "from processing.behavioral_metrics import cape_ratio, bubble_indicators, narrative_momentum_score; print('All 3 behavioral metrics import OK')"`
Expected: `All 3 behavioral metrics import OK`

**Step 3: Commit**

```bash
git add financial-researcher/processing/behavioral_metrics.py
git commit -m "feat: add behavioral_metrics.py — CAPE ratio, bubble indicators, narrative momentum"
```

---

## Task 5: Integrate New Metrics into ComprehensiveAnalysis and Orchestrator

**Files:**
- Modify: `financial-researcher/processing/metrics_calculator.py`
- Modify: `financial-researcher/processing/orchestrator.py`

**Step 1: Add new fields to ComprehensiveAnalysis dataclass in metrics_calculator.py**

After the existing `earnings_trend` field (~line 1154), add:

```python
    # Quant Metrics (Simons)
    momentum: Optional[MetricResult] = None
    volatility: Optional[MetricResult] = None
    mean_reversion: Optional[MetricResult] = None
    factor_exposure: Optional[MetricResult] = None
    statistical_anomalies: Optional[MetricResult] = None
    sector_relative_strength: Optional[MetricResult] = None
    correlation_regime: Optional[MetricResult] = None
    liquidity: Optional[MetricResult] = None
    return_distribution: Optional[MetricResult] = None

    # Behavioral Metrics (Shiller)
    cape: Optional[MetricResult] = None
    bubble_indicators: Optional[MetricResult] = None
    narrative_momentum: Optional[MetricResult] = None
```

**Step 2: Update aggregate_flags() in metrics_calculator.py to include new metrics**

In the `aggregate_flags` function, update the field_name list to include the new fields:

```python
    for field_name in ['piotroski', 'altman_z', 'ohlson_o', 'beneish_m',
                       'sloan_accrual', 'fcf_conversion', 'shareholder_yield',
                       'eva', 'owner_earnings', 'dupont', 'sustainable_growth',
                       'momentum', 'volatility', 'mean_reversion', 'factor_exposure',
                       'statistical_anomalies', 'sector_relative_strength',
                       'correlation_regime', 'liquidity', 'return_distribution',
                       'cape', 'bubble_indicators', 'narrative_momentum']:
```

**Step 3: Add new imports and calculation blocks to orchestrator.py**

Add to the imports section at the top of orchestrator.py, after existing metric imports:

```python
from .quant_metrics import (
    momentum_score,
    volatility_metrics,
    mean_reversion_signals,
    factor_exposure,
    statistical_anomalies,
    sector_relative_strength,
    correlation_regime,
    liquidity_metrics,
    return_distribution,
)
from .behavioral_metrics import (
    cape_ratio,
    bubble_indicators,
    narrative_momentum_score,
)
```

In `calculate_all_metrics()`, add after the `# === SUMMARY ===` section (before `aggregate_flags`):

```python
    # === QUANT METRICS (Simons) ===

    if company.price.price_history:
        try:
            analysis.momentum = momentum_score(company.price.price_history)
        except Exception:
            pass

        try:
            analysis.volatility = volatility_metrics(
                company.price.price_history,
                vix_prices=company.benchmarks.vix_prices if hasattr(company, 'benchmarks') else None,
            )
        except Exception:
            pass

        try:
            analysis.mean_reversion = mean_reversion_signals(company.price.price_history)
        except Exception:
            pass

        try:
            analysis.statistical_anomalies = statistical_anomalies(
                company.price.price_history,
                earnings_values=[f.net_income for f in reversed(company.financials_annual)] if company.financials_annual else None,
            )
        except Exception:
            pass

        try:
            analysis.liquidity = liquidity_metrics(company.price.price_history)
        except Exception:
            pass

        try:
            analysis.return_distribution = return_distribution(company.price.price_history)
        except Exception:
            pass

    # Factor exposure (uses API metrics + momentum)
    try:
        mom_12m = analysis.momentum.components.get("momentum_12m_skip1m", 0) / 100 if analysis.momentum else None
        analysis.factor_exposure = factor_exposure(
            pe_ratio=company.metrics.pe_ratio,
            pb_ratio=company.metrics.pb_ratio,
            roe=company.metrics.roe,
            accrual_ratio=analysis.sloan_accrual.value / 100 if analysis.sloan_accrual else None,
            market_cap=company.price.market_cap,
            momentum_12m=mom_12m,
        )
    except Exception:
        pass

    # Relative strength and correlation (need benchmark data)
    if hasattr(company, 'benchmarks') and company.benchmarks.spy_prices:
        try:
            analysis.sector_relative_strength = sector_relative_strength(
                company.price.price_history,
                company.benchmarks.sector_etf_prices or company.benchmarks.spy_prices,
                company.benchmarks.spy_prices,
            )
        except Exception:
            pass

        try:
            analysis.correlation_regime = correlation_regime(
                company.price.price_history,
                company.benchmarks.spy_prices,
            )
        except Exception:
            pass

    # === BEHAVIORAL METRICS (Shiller) ===

    # CAPE ratio
    if company.financials_annual and company.price.current_price > 0:
        try:
            earnings_hist = [f.net_income for f in reversed(company.financials_annual)]
            shares = company.financials_annual[0].shares_outstanding or company.price.shares_outstanding
            analysis.cape = cape_ratio(
                earnings_history=earnings_hist,
                current_price=company.price.current_price,
                shares_outstanding=shares,
            )
        except Exception:
            pass

    # Bubble indicators
    if company.price.price_history:
        try:
            earnings_hist = [f.net_income for f in reversed(company.financials_annual)] if company.financials_annual else None
            analysis.bubble_indicators = bubble_indicators(
                company.price.price_history,
                earnings_history=earnings_hist,
            )
        except Exception:
            pass

    # Narrative momentum (placeholder — requires news data to be passed through)
    # This will be populated by the orchestrator using news data when available
```

**Step 4: Add "simons" and "shiller" cases to format_for_expert()**

In the `expert_emphasis` dictionary in `format_for_expert()`, add:

```python
        "simons": [
            "\n## Simons-Relevant Highlights",
            f"- Momentum: See quant metrics above",
            f"- Volatility Regime: {result.comprehensive_analysis.volatility.components.get('regime', 'N/A') if result.comprehensive_analysis and result.comprehensive_analysis.volatility else 'N/A'}",
            f"- Factor Exposure: {result.comprehensive_analysis.factor_exposure.value if result.comprehensive_analysis and result.comprehensive_analysis.factor_exposure else 'N/A'}",
            f"- Relative Strength vs SPY: {result.comprehensive_analysis.sector_relative_strength.value if result.comprehensive_analysis and result.comprehensive_analysis.sector_relative_strength else 'N/A'}%",
        ],
        "shiller": [
            "\n## Shiller-Relevant Highlights",
            f"- CAPE Ratio: {result.comprehensive_analysis.cape.value if result.comprehensive_analysis and result.comprehensive_analysis.cape else 'N/A'}",
            f"- Bubble Score: {result.comprehensive_analysis.bubble_indicators.value if result.comprehensive_analysis and result.comprehensive_analysis.bubble_indicators else 'N/A'}/100",
            f"- Narrative Momentum: {result.comprehensive_analysis.narrative_momentum.value if result.comprehensive_analysis and result.comprehensive_analysis.narrative_momentum else 'N/A'}",
        ],
```

**Step 5: Add quant and behavioral sections to to_llm_context()**

In the `to_llm_context()` method of `AnalysisResult`, add new sections after the "Sustainable Growth" section:

```python
            # Quant Metrics
            if any([ca.momentum, ca.volatility, ca.mean_reversion, ca.factor_exposure]):
                lines.append("## Quant Metrics")

                if ca.momentum:
                    lines.append(f"### Momentum: {ca.momentum.value}%")
                    lines.append(f"Interpretation: {ca.momentum.interpretation}")
                    lines.append("")

                if ca.volatility:
                    lines.append(f"### Volatility (20d annualized): {ca.volatility.value}%")
                    lines.append(f"Regime: {ca.volatility.components.get('regime', 'N/A')}")
                    lines.append(f"Interpretation: {ca.volatility.interpretation}")
                    lines.append("")

                if ca.mean_reversion:
                    lines.append(f"### Mean Reversion Score: {ca.mean_reversion.value}")
                    lines.append(f"Interpretation: {ca.mean_reversion.interpretation}")
                    lines.append("")

                if ca.factor_exposure:
                    lines.append(f"### Factor Exposure: {ca.factor_exposure.value}")
                    lines.append(f"Interpretation: {ca.factor_exposure.interpretation}")
                    lines.append("")

                if ca.sector_relative_strength:
                    lines.append(f"### Relative Strength vs SPY: {ca.sector_relative_strength.value}%")
                    lines.append(f"Interpretation: {ca.sector_relative_strength.interpretation}")
                    lines.append("")

                if ca.return_distribution:
                    lines.append(f"### Risk/Return (Sharpe): {ca.return_distribution.value}")
                    lines.append(f"Max Drawdown: {ca.return_distribution.components.get('max_drawdown', 'N/A')}%")
                    lines.append(f"Interpretation: {ca.return_distribution.interpretation}")
                    lines.append("")

            # Behavioral Metrics
            if any([ca.cape, ca.bubble_indicators]):
                lines.append("## Behavioral/Valuation Metrics")

                if ca.cape:
                    lines.append(f"### CAPE Ratio: {ca.cape.value}")
                    lines.append(f"Excess CAPE Yield: {ca.cape.components.get('excess_cape_yield', 'N/A')}%")
                    lines.append(f"Implied 10yr Real Return: {ca.cape.components.get('implied_10yr_real_return', 'N/A')}%")
                    lines.append(f"Interpretation: {ca.cape.interpretation}")
                    lines.append("")

                if ca.bubble_indicators:
                    lines.append(f"### Bubble Score: {ca.bubble_indicators.value}/100")
                    lines.append(f"Interpretation: {ca.bubble_indicators.interpretation}")
                    lines.append("")

                if ca.narrative_momentum:
                    lines.append(f"### Narrative Momentum: {ca.narrative_momentum.value}")
                    lines.append(f"Interpretation: {ca.narrative_momentum.interpretation}")
                    lines.append("")
```

**Step 6: Run existing tests**

Run: `cd /Users/leozhang/Documents/GitHub/FAskills/financial-researcher && python -m processing.test_pipeline`
Expected: All existing tests pass (new fields have defaults, new calculations are additive).

**Step 7: Commit**

```bash
git add financial-researcher/processing/metrics_calculator.py financial-researcher/processing/orchestrator.py
git commit -m "feat: integrate quant and behavioral metrics into ComprehensiveAnalysis and orchestrator"
```

---

## Task 6: Update __init__.py Exports

**Files:**
- Modify: `financial-researcher/processing/__init__.py`

**Step 1: Add new exports**

Add after the existing metric calculator imports:

```python
# Quant metrics (Simons)
from .quant_metrics import (
    momentum_score,
    volatility_metrics,
    mean_reversion_signals,
    factor_exposure,
    statistical_anomalies,
    sector_relative_strength,
    correlation_regime,
    liquidity_metrics,
    return_distribution,
)

# Behavioral metrics (Shiller)
from .behavioral_metrics import (
    cape_ratio,
    bubble_indicators,
    narrative_momentum_score,
)
```

Add to `__all__` list:

```python
    # Quant metrics
    "momentum_score",
    "volatility_metrics",
    "mean_reversion_signals",
    "factor_exposure",
    "statistical_anomalies",
    "sector_relative_strength",
    "correlation_regime",
    "liquidity_metrics",
    "return_distribution",

    # Behavioral metrics
    "cape_ratio",
    "bubble_indicators",
    "narrative_momentum_score",
```

Update version:

```python
__version__ = "2.1.0"
```

**Step 2: Verify full import**

Run: `cd /Users/leozhang/Documents/GitHub/FAskills/financial-researcher && python -c "from processing import momentum_score, cape_ratio, bubble_indicators; print('Package exports OK')"`
Expected: `Package exports OK`

**Step 3: Commit**

```bash
git add financial-researcher/processing/__init__.py
git commit -m "feat: export new quant and behavioral metrics from processing package"
```

---

## Task 7: Create Jim Simons Expert Prompt

**Files:**
- Create: `financial-researcher/experts/jim_simons.md`

**Step 1: Write the expert prompt**

Create the file following the exact pattern from `experts/_template.md` and existing experts like `michael_burry.md`. The prompt should include:

- **Frontmatter:** name, description, data_requirements, thirteenf_source
- **Identity block:** Jim Simons persona — quantitative, probability-focused, data-over-narrative
- **Philosophy:** 3-5 paragraphs on statistical arbitrage, factor investing, pattern recognition
- **Data provided block:** Same template variables as other experts, plus `{quant_metrics_json}` for pre-calculated quant metrics
- **9 analysis criteria:** momentum_profile, mean_reversion_setup, factor_exposure, volatility_regime, statistical_edge, relative_strength, liquidity_execution, correlation_structure, risk_reward_profile
- **Forward-looking:** Probability-framed predictions, 1-6 month horizon, position sizing guidance
- **Holdings context:** Renaissance Technologies 13-F
- **Output JSON:** Same structure as other experts with quant-specific analysis fields
- **Voice guidance:** Probabilistic, data-driven, never use subjective language

Key differences from other experts:
- Time horizon: 1-6 months (shortest of all experts)
- Signal framing: Probabilities, not convictions
- No SEC filing analysis, no narrative — pure data
- Position sizing recommendation based on Kelly criterion / volatility

This is a large file (~350 lines). The implementing engineer should reference `michael_burry.md` as the structural template and adapt all sections to Simons' quantitative philosophy.

**Step 2: Commit**

```bash
git add financial-researcher/experts/jim_simons.md
git commit -m "feat: add Jim Simons quant expert prompt"
```

---

## Task 8: Create Robert Shiller Expert Prompt

**Files:**
- Create: `financial-researcher/experts/robert_shiller.md`

**Step 1: Write the expert prompt**

Same pattern as Task 7 but for Shiller's behavioral economics perspective:

- **Frontmatter:** name, description, data_requirements (income_statements, financial_metrics, company_facts, prices, news, analyst_estimates), thirteenf_source: none
- **Identity block:** Robert Shiller persona — academic, behavioral, long-term valuation
- **Philosophy:** 3-5 paragraphs on CAPE, irrational exuberance, narrative economics, mean reversion
- **Data provided block:** Standard template variables plus `{behavioral_metrics_json}`
- **7 analysis criteria:** cape_valuation, bubble_risk_assessment, narrative_analysis, mean_reversion_probability, market_psychology, historical_analogues, long_term_return_forecast
- **Forward-looking:** 5-10 year return forecasts, bubble probability, historical parallels
- **Holdings context:** "No holdings — academic perspective" (Shiller is not a fund manager)
- **Output JSON:** Same structure with Shiller-specific analysis fields
- **Voice guidance:** Academic but accessible, historical references, respectful uncertainty

Key differences:
- No 13-F holdings (academic)
- Longest time horizon (5-10 years)
- Heavy use of historical analogues
- Explicit bubble probability assessment

**Step 2: Commit**

```bash
git add financial-researcher/experts/robert_shiller.md
git commit -m "feat: add Robert Shiller behavioral economist expert prompt"
```

---

## Task 9: Update SKILL.md Orchestration

**Files:**
- Modify: `financial-researcher/SKILL.md`

This is the largest modification. Key changes:

**Step 1: Update orchestration diagram** — 7 → 9 experts

**Step 2: Update data routing matrix** — Add JS and RS columns with the routing from the design doc

**Step 3: Update data fetch sequence** — Add 3 new price fetches (SPY, sector ETF, VIX) and Renaissance 13-F fetch

**Step 4: Update processing layer usage** — Add quant_metrics and behavioral_metrics sections, show new `format_for_expert()` cases

**Step 5: Update subagent dispatch** — 7 → 9 parallel Task calls

**Step 6: Update consolidation logic** — Agreement matrix now 9 columns, signal tally for 9 experts

**Step 7: Update guru table** — Add Simons and Shiller rows

**Step 8: Update report template references** — 9 expert sections

**Step 9: Update validation checklist** — Add quant and behavioral metric checks

**Step 10: Commit**

```bash
git add financial-researcher/SKILL.md
git commit -m "feat: update SKILL.md orchestration for 9-expert parallel dispatch"
```

---

## Task 10: Update Report Template and Plugin Version

**Files:**
- Modify: `financial-researcher/templates/consolidated_report_template.md`
- Modify: `financial-researcher/.claude-plugin/plugin.json`

**Step 1: Update report template**

Add Simons and Shiller sections to the report template. Update agreement matrix headers from `WB|BG|PL|CW|GS|RD|MB` to `WB|BG|PL|CW|GS|RD|MB|JS|RS`.

**Step 2: Version bump plugin.json**

Change version from `"2.0.0"` to `"2.1.0"`.

**Step 3: Commit**

```bash
git add financial-researcher/templates/consolidated_report_template.md financial-researcher/.claude-plugin/plugin.json
git commit -m "feat: update report template for 9 experts, bump version to 2.1.0"
```

---

## Task 11: Run Full Test Suite and Verify

**Step 1: Run processing layer tests**

Run: `cd /Users/leozhang/Documents/GitHub/FAskills/financial-researcher && python -m processing.test_pipeline`
Expected: All tests pass.

**Step 2: Verify all imports work**

Run: `cd /Users/leozhang/Documents/GitHub/FAskills/financial-researcher && python -c "from processing import run_analysis, format_for_expert, momentum_score, cape_ratio; print('Full integration OK')"`
Expected: `Full integration OK`

**Step 3: Quick smoke test with synthetic data**

Run a quick test that creates minimal synthetic data and runs `calculate_all_metrics()` to verify the new quant and behavioral metrics calculate without errors.

**Step 4: Final commit if any fixes needed**

```bash
git add -A
git commit -m "fix: address integration issues from testing"
```
